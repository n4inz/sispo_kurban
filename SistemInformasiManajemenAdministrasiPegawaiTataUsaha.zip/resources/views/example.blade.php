@extends('layout.app')

@section('title', 'An Example Page')

@section('content')
<p>halo mas</p>
@endsection

@section('script')
<script>
    console.log("halo mas")
</script>
@endsection
