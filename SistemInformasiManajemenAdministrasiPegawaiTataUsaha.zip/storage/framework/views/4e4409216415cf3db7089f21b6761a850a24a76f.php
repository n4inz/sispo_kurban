<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>
<script>
    $('.btn-mobile-sidebar').click(function(){
        $('aside').toggleClass("-translate-x-full relative");
    });

    function toast(message, type) {
        $('#toast-' + type).toggleClass('hidden flex');
        $(`#toast-${type} > .msg`).html(message);
        setTimeout(function () {
            $('#toast-' + type).toggleClass('hidden flex');
        }, 3000);
    }
</script>
<?php /**PATH /mnt/data/Project/Laravel/SistemInformasiManajemenAdministrasiPegawaiTataUsaha/resources/views/layout/script.blade.php ENDPATH**/ ?>