<aside class="w-64 bg-[#005331] shadow-sm drop-shadow-lg absolute inset-y-0 left-0 transform -translate-x-full lg:relative lg:translate-x-0 transition duration-200 ease-in-out " aria-label="Sidebar">
    <div class="px-3 py-4 rounded dark:bg-gray-800 ">
        <div class="text-center">
            <img class="mx-auto w-24 mb-1" src="<?php echo e(env('LOGO')); ?>" alt="" srcset="">
            <h4 class="font-semibold text-white">Baznas Kurban Berasama</h4>
        </div>
        <?php echo $__env->make('layout.sidebar._menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</aside>
<?php /**PATH /mnt/data/Project/Laravel/SistemInformasiManajemenAdministrasiPegawaiTataUsaha/resources/views/layout/sidebar/index.blade.php ENDPATH**/ ?>