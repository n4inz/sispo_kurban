<aside class="w-64 shadow-sm drop-shadow-lg absolute inset-y-0 left-0 transform -translate-x-full lg:relative lg:translate-x-0 transition duration-200 ease-in-out bg-white" aria-label="Sidebar">
    <div class="px-3 py-4 rounded dark:bg-gray-800 ">
        <div class="text-center">
            <img class="mx-auto w-16 mb-1" src="/img/logo-wikrama-bogor.png" alt="" srcset="">
            <h4 class="font-semibold text-blue-800">SIMAP Tata Usaha</h4>
        </div>
        <?php echo $__env->make('layout.sidebar._menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</aside>
<?php /**PATH /mnt/data/Project/Laravel/Sistem Informasi Manajemen Administrasi Pegawai Tata Usaha/resources/views/layout/sidebar/index.blade.php ENDPATH**/ ?>