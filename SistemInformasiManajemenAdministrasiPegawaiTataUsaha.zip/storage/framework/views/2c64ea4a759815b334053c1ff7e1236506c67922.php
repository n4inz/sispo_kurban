<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <p class="mb-8 text-2xl font-semibold text-gray-800">
        Dashboard
    </p>

    <div class="flex flex-row justify-between flex-wrap space-x-3 space-y-5">
        <?php if($user->role !== "ADMIN"): ?>
        <div class="flex justify-between pl-6 pt-6 max-w-3xl bg-white rounded-lg border border-gray-200 shadow-md dark:bg-gray-800 dark:border-gray-700">
            <div>
                <p class="font-normal text-gray-700 dark:text-gray-400">Selamat datang kembali,</p>
                <h5 class="text-xl font-semibold tracking-tight text-gray-900 dark:text-white"><?php echo e($user->name); ?>!</h5>
                
            </div>
            <img class="max-w-md" src="<?php echo e(asset('img/svg/vector-user-dashboard.svg')); ?>" alt="" srcset="">
        </div>
        <?php else: ?>
            <div class="space-y-4">
                <div class="flex  justify-between p-5  bg-white rounded-lg border border-gray-200 shadow-md dark:bg-gray-800 dark:border-gray-700">
                    <div>
                        <canvas class="w-full h-96" id="myChartLine"></canvas>
                    </div>
    
                
                </div>
    
                <div class="flex space-x-6 justify-between p-5  bg-white rounded-lg border border-gray-200 shadow-md dark:bg-gray-800 dark:border-gray-700">
                    <div>
                        <canvas class="w-full h-96" id="myChart"></canvas>
                    </div>
    
                    <div >
                        <canvas class="w-full h-96" id="myChart2"></canvas>
                    </div>
                    
    
                </div>

            </div>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    const ctx = document.getElementById('myChart');
    var years = <?php echo e(json_encode($years)); ?>;
    var dataCount = <?php echo e(json_encode($dataCounts)); ?>;
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: years,
        datasets: [{
          label: 'Data Kurban',
          data: dataCount,
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });

    const ctx2 = document.getElementById('myChart2');
  
    new Chart(ctx2, {
        type: 'pie',
        data: {
        labels: years,
        datasets: [{
            label: 'Data Kurban',
            data: dataCount,
            borderWidth: 1
        }]
        },
        options: {
        scales: {
            y: {
            beginAtZero: true
            }
        }
        }
    });

    const ctxLine = document.getElementById('myChartLine');
  
    new Chart(ctxLine, {
      type: 'line',
      data: {
      labels: years,
      datasets: [{
          label: 'Data Kurban',
          data: dataCount,
          borderWidth: 1
      }]
      },
      options: {
      scales: {
          y: {
          beginAtZero: true
          }
      }
      }
    });
  </script>
 
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/data/Project/Laravel/SistemInformasiManajemenAdministrasiPegawaiTataUsaha/resources/views/dashboard.blade.php ENDPATH**/ ?>