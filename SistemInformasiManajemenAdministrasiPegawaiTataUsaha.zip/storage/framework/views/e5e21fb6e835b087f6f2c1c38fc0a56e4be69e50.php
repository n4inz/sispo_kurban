<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', $user->role === 'ADMIN' ? 'Kelola User' : 'Daftar Pegawai'); ?>

<?php $__env->startSection('content'); ?>
    <p class="mb-4 text-2xl font-semibold text-gray-800">
       Kelompok Kurban
    </p>


    <div id="employeeTabContent">
        <div class="rounded-lg" id="employee" role="tabpanel"
            aria-labelledby="employee-tab">
            <div class="flex flex-wrap">
                <?php $__currentLoopData = $pakets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="block w-[32%] mb-4 mr-2 max-w-sm p-6 bg-white border border-gray-200 rounded-lg shadow hover:bg-gray-100 dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
                        <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
                            <span class="text-green-500"><?php echo e($paket->nama_hewan); ?> - BKR<?php echo e($paket->id); ?></span>
                        </h5>
                        <p>Nama Kelompok:</p>
                        <?php $__currentLoopData = $paket->user_kelompok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelompok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($kelompok->user): ?>
                                <div class="font-normal text-gray-700 dark:text-gray-400 flex items-center space-x-2">
                                    <span><?php echo e($kelompok->user->name); ?></span>
                                    <?php if($kelompok->status_paid == 2): ?>
                                        <span class="text-green-500">Lunas</span>
                                    <?php elseif($kelompok->status_paid == 1): ?>
                                        <span class="text-yellow-500">Waiting</span>
                                    <?php elseif($kelompok->status_paid == 0): ?>
                                        <span class="text-red-500">Belum lunas</span>
                                    <?php endif; ?>
                                </div>
                                
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /mnt/data/Project/Laravel/SistemInformasiManajemenAdministrasiPegawaiTataUsaha/resources/views/Kurban/paket_kurban.blade.php ENDPATH**/ ?>