<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="icon" href="<?php echo e(asset('img/svg/baznas.png')); ?>" type="image/x-icon">
<link href="/css/app.css" rel="stylesheet">
<script src="https://kit.fontawesome.com/6b35a228d3.js" crossorigin="anonymous"></script>
<?php /**PATH /mnt/data/Project/Laravel/SistemInformasiManajemenAdministrasiPegawaiTataUsaha/resources/views/layout/head.blade.php ENDPATH**/ ?>